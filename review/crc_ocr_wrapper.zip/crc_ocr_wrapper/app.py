#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, shutil, subprocess, sys, time, hashlib, platform
from pathlib import Path
from datetime import datetime

REPO = Path(".").resolve()

SCRIPTS = [
    "scripts/ingest_pdf.py",
    "scripts/check_alignment.py",
    "scripts/make_overlays.py",
    "scripts/run_ocr.py",
    "scripts/qa_overlay_from_results.py",
    "scripts/validate_run.py",
    "scripts/export_to_excel.py",
    "scripts/common.py",
    "scripts/expand_grid.py",
]

CONFIGS = [
    "configs/ocr.yaml",
    "configs/models.yaml"
]

def sh(cmd, cwd=None, check=True):
    print(f"[run] {cmd}")
    st = time.time()
    p = subprocess.run(cmd, shell=True, cwd=cwd)
    dt = time.time() - st
    if check and p.returncode != 0:
        raise SystemExit(f"Command failed ({p.returncode}): {cmd}")
    return dt, p.returncode

def newest_run_dir(artifacts_dir: Path) -> Path:
    runs = [p for p in artifacts_dir.glob("*") if p.is_dir()]
    if not runs: raise SystemExit("No artifacts/ run directories found.")
    return sorted(runs)[-1]

def sha256_file(path: Path) -> str:
    if not path.exists(): return ""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()

def capture_env(dst: Path):
    dst.mkdir(parents=True, exist_ok=True)
    # Python version
    (dst/"python.txt").write_text(sys.version, encoding="utf-8")
    # pip freeze (best-effort)
    try:
        out = subprocess.check_output([sys.executable, "-m", "pip", "freeze"], text=True)
        (dst/"pip_freeze.txt").write_text(out, encoding="utf-8")
    except Exception as e:
        (dst/"pip_freeze.txt").write_text(f"error: {e}", encoding="utf-8")
    # OS / platform
    (dst/"os.txt").write_text(platform.platform(), encoding="utf-8")
    # Tools
    tool_lines = []
    for cmd in [["tesseract","-v"], [sys.executable,"-c","import cv2;print('opencv',cv2.__version__)"]]:
        try:
            out = subprocess.check_output(cmd, text=True)
            tool_lines.append(out)
        except Exception as e:
            tool_lines.append(f"{' '.join(cmd)} -> error: {e}")
    (dst/"tools.txt").write_text("\n".join(tool_lines), encoding="utf-8")

def snapshot_configs(run_dir: Path, template: Path):
    snap = run_dir/"configs_snapshot"
    snap.mkdir(parents=True, exist_ok=True)
    shutil.copy2(template, snap/"template.json")
    for cfg in CONFIGS:
        p = REPO/cfg
        if p.exists():
            shutil.copy2(p, snap/p.name)
    lines = []
    for p in snap.glob("*"):
        lines.append(f"{sha256_file(p)}  {p.name}")
    (snap/"checksums.txt").write_text("\n".join(lines), encoding="utf-8")

def snapshot_scripts(run_dir: Path):
    dst = run_dir/"scripts_archive"
    dst.mkdir(parents=True, exist_ok=True)
    for s in SCRIPTS:
        p = REPO/s
        if p.exists():
            shutil.copy2(p, dst/p.name)

def write_manifest(run_dir: Path, data: dict):
    (run_dir/"MANIFEST.json").write_text(json.dumps(data, indent=2), encoding="utf-8")

def main():
    ap = argparse.ArgumentParser(description="CRC OCR pipeline wrapper")
    ap.add_argument("--pdf", required=True, help="path to input PDF")
    ap.add_argument("--template", required=True, help="path to template.json")
    ap.add_argument("--export", default=None, help="output xlsx path (default exports/<run_id>.xlsx)")
    ap.add_argument("--notes", default="", help="note to include in manifest")
    ap.add_argument("--strict", action="store_true", help="fail on validation gate error")
    ap.add_argument("--threshold", type=float, default=None, help="override checkbox threshold")
    ap.add_argument("--near", type=float, default=0.03, help="± margin around threshold for 'near_threshold' flag")
    args = ap.parse_args()

    artifacts = REPO/"artifacts"
    artifacts.mkdir(exist_ok=True)

    pre = set([p.name for p in artifacts.glob("*") if p.is_dir()])
    t0 = time.time()

    # Step 0: ingest
    duration = {}
    d, _ = sh(f"{sys.executable} scripts/ingest_pdf.py --pdf \"{args.pdf}\"")
    duration["ingest_pdf"] = d

    post = set([p.name for p in artifacts.glob("*") if p.is_dir()])
    created = sorted(list(post - pre))
    if not created:
        run_dir = newest_run_dir(artifacts)
    else:
        run_dir = artifacts/created[-1]

    (run_dir/"input").mkdir(exist_ok=True)
    try:
        shutil.copy2(args.pdf, run_dir/"input"/"survey.pdf")
    except Exception:
        pass

    snapshot_scripts(run_dir)
    snapshot_configs(run_dir, Path(args.template))
    capture_env(run_dir/"env")

    d,_ = sh(f"{sys.executable} scripts/check_alignment.py --template \"{args.template}\"")
    duration["check_alignment"] = d

    d,_ = sh(f"{sys.executable} scripts/make_overlays.py --template \"{args.template}\"")
    duration["make_overlays"] = d

    d,_ = sh(f"{sys.executable} scripts/run_ocr.py --template \"{args.template}\"")
    duration["run_ocr"] = d

    d,_ = sh(f"{sys.executable} scripts/qa_overlay_from_results.py --template \"{args.template}\"")
    duration["qa_overlay_from_results"] = d

    gate_cmd = f"{sys.executable} scripts/validate_run.py --template \"{args.template}\""
    if args.strict:
        gate_cmd += " --fail-on-error"
    try:
        d,_ = sh(gate_cmd, check=args.strict)
        duration["validate_run"] = d
    except SystemExit as e:
        duration["validate_run"] = -1
        print(f"[warn] Validation gate failed: {e}")
        if args.strict:
            raise

    export_path = args.export or (REPO/"exports"/f"{run_dir.name}.xlsx")
    export_path = Path(export_path)
    export_path.parent.mkdir(parents=True, exist_ok=True)
    threshold_arg = f" --threshold {args.threshold}" if args.threshold is not None else ""
    d,_ = sh(f"{sys.executable} scripts/export_to_excel.py --run-dir \"{run_dir}\" --out \"{export_path}\"{threshold_arg} --near {args.near}")
    duration["export_to_excel"] = d

    manifest = {
        "run_id": run_dir.name,
        "timestamp": datetime.utcnow().isoformat()+"Z",
        "notes": args.notes,
        "template": str(Path(args.template)),
        "export": str(export_path),
        "durations_sec": duration,
        "gates": {"strict": bool(args.strict)}
    }
    (run_dir/"README.md").write_text(
        f"# Run {run_dir.name}\n\nExport: {export_path}\n\nDurations (s):\n" +
        "\n".join([f"- {k}: {v:.2f}" if v>=0 else f"- {k}: FAILED" for k,v in duration.items()]),
        encoding="utf-8"
    )
    write_manifest(run_dir, manifest)

    print(f"Done. Excel: {export_path}")

if __name__ == "__main__":
    main()
